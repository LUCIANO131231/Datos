<!DOCTYPE html>
<html>

<head>
  <!-- Basic -->
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- Mobile Metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <!-- Site Metas -->
    <meta name="title" content="Encuentra el cumpleaños de una persona por sus nombres y apellidos">
    <link rel="icon" type="image/x-icon" href="/images/icono-dni.png">
    <meta name="description" content="Explora nuestra sofisticada herramienta de búsqueda para acceder a información detallada de personas a través de su DNI o nombres y apellidos. ¡Desbloquea un mundo de posibilidades con RENIEC, SUNAT y mucho más!">
    <meta name="keywords" content="App para sacar cumple, DNI, RENIEC, SUNAT, Buscador de personas, Datos personales, Búsqueda elegante, cuando es su cumpleaños, como saber que dia es su cumpleaños">
    <meta name="robots" content="index, follow">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="language" content="es">


  <title>BUSCAR CUMPLEAÑOS POR NOMBRES</title>

  <!-- slider stylesheet -->
  <link rel="stylesheet" type="text/css">

  <!-- bootstrap core css -->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />

  <!-- fonts style -->
  <link href="https://fonts.googleapis.com/css?family=Dosis:400,500|Poppins:400,700&display=swap" rel="stylesheet">
  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet" />
  <!-- responsive style -->
  <link href="css/responsive.css" rel="stylesheet" />
</head>

<body>
  <div class="hero_area-">
    <!-- header section strats -->
    <header class="header_section">
      <div class="container-fluid">
        <nav class="navbar navbar-expand-lg custom_nav-container ">
          <a class="navbar-brand" href="index.php">
            <img src="images/buscar-personas-dni.png" alt="logo-buscar-personas">
          </a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>

          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <div class="d-flex mx-auto flex-column flex-lg-row align-items-center">
              <ul class="navbar-nav  ">
                <li class="nav-item active">
                  <a class="nav-link" href="index.php">BUSCAR POR DNI <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="buscar-dni-por-nombre.php">BUSCAR POR NOMBRES </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="buscar-cumpleanios-por-nombres.php">BUSCAR CUMPLEAÑOS </a>
                </li>
              </ul>
            </div>
            <div class="quote_btn-container  d-flex justify-content-center">
              <a href="">
                Call: +023 1245567697
              </a>
            </div>
          </div>
        </nav>
      </div>
    </header>
    <!-- end header section -->
  </div>

  <!-- about section -->

  <!-- service section -->
  <section class="service_section layout_padding">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-8 offset-md-2">
          <h2 class="custom_heading text-center">
            BUSCAR POR <span>DNI</span>
          </h2>
        </div>
      </div>

      <div class="row">
        <div class="col-md-8 offset-md-2">
          <div class="container layout_padding2">
            <div class="row">
              <div class="col-md-4">
                <div class="img_box">
                  <img src="images/client.jpg" alt="">
                </div>
                <div class="detail_box text-left">
                  <h6>
                    Buscar nombres y apellidos por DNI
                  </h6>
                  <p>
                      El Documento Nacional de Identidad (DNI) es un documento esencial en la vida de cualquier ciudadano peruano. En muchas ocasiones, la necesidad de encontrar el número de DNI de alguien a partir de sus nombres y apellidos se vuelve imperativa. En este artículo, te proporcionaremos una guía completa sobre cómo realizar esta búsqueda y, además, exploraremos los usos más comunes de esta información.
                  </p>

                    <p>Por qué Necesitas Encontrar un Número de DNI
                      Encontrar el número de DNI de una persona basado en sus nombres y apellidos puede tener un impacto significativo en diversas situaciones, incluyendo:
                    </p>

                    <p>Verificación de Identidad: La necesidad de verificar la identidad de una persona en situaciones legales, financieras o laborales es crucial.
                      Trámites Legales Eficientes: Agiliza procesos legales como la compra de propiedades o la presentación de documentos legales.
                      Reuniones Familiares Emocionantes: A veces, es necesario encontrar a familiares perdidos o separados durante mucho tiempo.
                      Cómo Encontrar un Número de DNI con Nombres y Apellidos: Guía Paso a Paso
                      Nuestra herramienta de búsqueda de DNI está diseñada para ser rápida y fácil de usar. Estos son los pasos para utilizarla:
                    </p>
                    <p>Ingresa los Nombres y Apellidos completos: Proporciona los nombres y apellidos completos de la persona cuyo DNI deseas encontrar en nuestro formulario de búsqueda.
                      Haz Clic en "Buscar": Una vez ingresada la información, presiona el botón "Buscar" y espera a que nuestro sistema procese la solicitud.
                      Recibe el Número de DNI: En cuestión de segundos, recibirás el número de DNI de la persona buscada.
                    </p>
                </div>
              </div>
              <div class="col-md-4">
                <div class="img_box">
                  <img src="images/search-icon.png" alt="">
                </div>
                <div class="detail_box">
                  <h6>
                    BUSCAR CUMPLEAÑOS POR NOMBRES
                  </h6>
                  <p>
                    En el siguiente campo ingrese el nombre y sus apellidos
                  </p>

                  <div class="form_container ">
                    <div class="row">
                      <div class="col-md-12 text-left">
                        <form name="search" id="search" method="post" >
                            <div class="form-group row">
                                <label for="inputEmail3" class="col-sm-6 col-form-label">Nombres: </label>
                                <div class="col-sm-6">
                                    <input type="text" name="nombres" id="nombres"  class="form-control">
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="inputEmail3" class="col-sm-6 col-form-label">APELLIDO PATERNO: </label>
                                <div class="col-sm-6">
                                    <input type="text" name="ape_pat" id="ape_pat"  class="form-control">
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="inputEmail3" class="col-sm-6 col-form-label">APELLIDO MATERNO: </label>
                                <div class="col-sm-6">
                                    <input type="text" name="ape_mat" id="ape_mat"  class="form-control">
                                </div>
                            </div>

                          <div class="d-flex justify-content-center mt-4">
                            <button class="btn btn-primary mb-3">
                              BUSCAR
                            </button>
                          </div>
                        </form>
                      </div>

                        <div class="col-md-12">
                            <h4> Resultados de su búsqueda</h4>
                               <p id="fecha_cumpleanios" style="color: green"></p>
                        </div>
                    </div>
                  </div>

                </div>
              </div>
              <div class="col-md-4">
                <div class="img_box">
                  <img src="images/icono-dni.png" alt="">
                </div>
                <div class="detail_box">
                  <h6>
                    Usos comunes
                  </h6>
                  <p class="text-left">
                      Usos Comunes de la Búsqueda de DNI: ¿Por Qué es Importante?
                      La búsqueda de un número de DNI a partir de nombres y apellidos tiene aplicaciones prácticas en una variedad de situaciones, incluyendo:
                  </p>


                        <ol class="text-left">
                            <li>Verificación de Antecedentes: Empleadores y arrendadores pueden utilizar esta información para tomar decisiones informadas al contratar o arrendar propiedades.</li>
                            <li>Trámites Bancarios Simplificados: En algunos procedimientos bancarios, es necesario verificar la identidad de un cliente, y nuestra herramienta puede simplificar este proceso.</li>
                            <li>Reuniones Familiares Emotivas: Si buscas reunirte con familiares perdidos, esta herramienta puede ayudarte a localizarlos.</li>
                        </ol>

                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- end service section -->

  <!-- buy section -->

  <section class="buy_section layout_padding">
    <div class="container">
      <h2>
        Uso de datos y privacidad
      </h2>
      <p>
       No almacenamos datos de nadie, todos los datos son provenientes de fuentes públicas, si usted desea restringir sus datos, comuniquese al correo <b>contacto@el-dni.com</b>, de esa forma filtrar antes de mostrar alguna información personal suya.
      </p>
    </div>
  </section>

  <!-- end buy section -->

  <!-- end map section -->

  <!-- info section -->
  <section class="info_section layout_padding2">
    <div class="container">
      <div class="info_items">
        <a href="">
          <div class="item ">
            <div class="img-box box-1">
              <img src="" alt="">
            </div>
            <div class="detail-box">
              <p>
                Location
              </p>
            </div>
          </div>
        </a>
        <a href="">
          <div class="item ">
            <div class="img-box box-2">
              <img src="" alt="">
            </div>
            <div class="detail-box">
              <p>
                +02 1234567890
              </p>
            </div>
          </div>
        </a>
        <a href="">
          <div class="item ">
            <div class="img-box box-3">
              <img src="" alt="">
            </div>
            <div class="detail-box">
              <p>
                contacto@el-dni.com
              </p>
            </div>
          </div>
        </a>
      </div>
    </div>
  </section>

  <!-- end info_section -->

  <!-- footer section -->
  <section class="container-fluid footer_section">
    <p>
      &copy; 2023
      <a href="https://el-dni.com/">Todos los derechos reservados</a>
    </p>
  </section>
  <!-- footer section -->

  <script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
  <script type="text/javascript" src="js/bootstrap.js"></script>

</body>

</html>

<script>
    $(document).ready(function() {

        $('#search').submit(function (e) {
            e.preventDefault();

            $.ajax({
                type: 'POST',
                url: 'search.php',
                data: {
                    tipo: 3,
                    nombres: $('#nombres').val(),
                    ape_pat: $('#ape_pat').val(),
                    ape_mat: $('#ape_mat').val(),
                }
            })
                .done((data) => {
                  var datos =  JSON.parse(data)
                    var dat = datos.data.nombres + ", "+ datos.data.apellido_paterno +" "+datos.data.apellido_materno
                    var dat2 = " cumple años el "
                    $('#fecha_cumpleanios').html(dat + dat2 + datos.data.cumple)
                })
                .fail((err) => {
                    console.error(err);
                })
                .always(() => {
                    console.log('always called');
                });
        });
    });
</script>